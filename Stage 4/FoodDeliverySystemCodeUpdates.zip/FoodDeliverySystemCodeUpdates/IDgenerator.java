/**
 * IDgenerator
 *
 * Provides simple incrementing IDs for project entities.
 */
public class IDgenerator {

    private static int userID = 1;
    private static int adminID = 1;
    private static int deliveryID = 1;
    private static int restaurantID = 1;
    private static int menuItemID = 1;
    private static int orderID = 1;
    private static int cartID = 1;
    private static int reviewID = 1;

    public static int generateUserID() { return userID++; }
    public static int generateAdminID() { return adminID++; }
    public static int generateDeliveryPersonID() { return deliveryID++; }
    public static int generateRestaurantID() { return restaurantID++; }
    public static int generateMenuItemID() { return menuItemID++; }
    public static int generateOrderID() { return orderID++; }
    public static int generateCartID() { return cartID++; }
    public static int generateReviewID() { return reviewID++; }
}
