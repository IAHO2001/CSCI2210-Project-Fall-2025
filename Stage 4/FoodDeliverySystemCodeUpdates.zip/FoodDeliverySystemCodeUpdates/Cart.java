import java.util.ArrayList;
import java.util.List;

/**
 * Cart
 *
 * Represents a user's shopping cart while ordering from a restaurant.
 */
public class Cart {

    private int cartID;
    private User customer;
    private List<MenuItem> items;
    private double totalPrice;

    public Cart(User customer) {
        this.cartID = IDgenerator.generateCartID();
        this.customer = customer;
        this.items = new ArrayList<>();
        this.totalPrice = 0.0;
    }

    public void addItem(MenuItem item) {
        items.add(item);
        calculateTotal();
    }

    public void removeItem(MenuItem item) {
        items.remove(item);
        calculateTotal();
    }

    public double calculateTotal() {
        totalPrice = 0.0;
        for (MenuItem item : items) totalPrice += item.getPrice();
        return totalPrice;
    }

    public void deleteCart() {
        items.clear();
        totalPrice = 0.0;
    }

    public List<MenuItem> getItems() { return items; }
    public User getCustomer() { return customer; }
    public int getCartID() { return cartID; }
    public double getTotalPrice() { return totalPrice; }
}
