/**
 * Payment
 *
 * Abstract base class for payment types.
 */
public abstract class Payment {
    protected double amount;

    public Payment(double amount) { this.amount = amount; }

    public abstract boolean processPayment();

    public double getAmount() { return amount; }
}
