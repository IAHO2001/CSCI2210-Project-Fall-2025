/**
 * User
 *
 * Represents a customer in the food delivery system.
 * Includes a backwards-compatible constructor that accepts an address.
 */
public class User extends Person {

    private int userID;
    private String password;
    private String address; // optional

    public User(String name, String email, String password, String phoneNumber) {
        super(name, email, phoneNumber);
        this.password = password;
        this.userID = IDgenerator.generateUserID();
    }

    // Backwards-compatible constructor (older LoadSystem used 5 args)
    public User(String name, String email, String phoneNumber, String password, String address) {
        super(name, email, phoneNumber);
        this.password = password;
        this.userID = IDgenerator.generateUserID();
        this.address = address;
    }

    public int getUserID() { return userID; }
    public String getPassword() { return password; }
    public String getAddress() { return address; }

    @Override
    public String toString() {
        return "User ID: " + userID + ", Name: " + getName() + ", Email: " + getEmail();
    }
}
