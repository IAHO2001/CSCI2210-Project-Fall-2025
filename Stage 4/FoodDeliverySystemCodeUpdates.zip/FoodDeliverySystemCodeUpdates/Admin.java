/**
 * Admin.java
 *
 * Admin inherits Person and represents an administrative user with a role.
 */
public class Admin extends Person {
    private int adminID;
    private String role;
    private String password;

    public Admin(String name, String email, String password, String phoneNumber, String role) {
        super(name, email, phoneNumber);
        this.password = password;
        this.adminID = IDgenerator.generateAdminID();
        this.role = role;
    }

    public String getPassword() { return password; }
    public int getAdminID() { return adminID; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    @Override
    public String toString() {
        return "Admin ID: " + adminID + ", Name: " + this.getName() + ", Role: " + role;
    }
}
