import java.util.List;
import java.util.Scanner;

/**
 * DriverMenuManager
 *
 * Implements driver actions: view orders, complete order, and view reviews.
 */
public class DriverMenuManager {
    private Scanner in = new Scanner(System.in);

    public void viewAssignedOrders(DeliveryPerson driver) {
        List<Order> orders = driver.getAssignedOrders();
        System.out.println("\n--- Assigned Orders ---");
        if (orders == null || orders.isEmpty()) { System.out.println("You have no assigned orders."); return; }
        for (Order order : orders) {
            System.out.printf("Order ID: %d | Restaurant: %s | Total: $%.2f | Status: %s%n",
                    order.getOrderID(), order.getRestaurant().getName(), order.getTotalPrice(), order.getStatus());
        }
    }

    public void completeOrder(DeliveryPerson driver) {
        List<Order> orders = driver.getAssignedOrders();
        if (orders == null || orders.isEmpty()) { System.out.println("No active orders to complete."); return; }

        System.out.println("\n--- Complete Order ---");
        for (int i = 0; i < orders.size(); i++) {
            Order order = orders.get(i);
            System.out.printf("%d. Order ID: %d | Restaurant: %s | Status: %s%n",
                    i + 1, order.getOrderID(), order.getRestaurant().getName(), order.getStatus());
        }

        System.out.print("Select an order to mark as completed: ");
        if (!in.hasNextInt()) { in.nextLine(); System.out.println("Invalid input."); return; }
        int choice = in.nextInt(); in.nextLine();
        if (choice < 1 || choice > orders.size()) { System.out.println("Invalid choice."); return; }

        Order selectedOrder = orders.get(choice - 1);
        selectedOrder.setStatus("Completed");
        driver.removeAssignedOrder(selectedOrder);
        driver.setAvailability("Available");
        System.out.println("Order ID " + selectedOrder.getOrderID() + " has been marked as completed.");

        // Assign next pending order if available
        if (!driver.getSystem().getPendingOrders().isEmpty()) {
            Order nextOrder = driver.getSystem().getPendingOrders().poll();
            driver.getSystem().assignDeliveryPerson(nextOrder);
            System.out.println("A queued order (ID " + nextOrder.getOrderID() + ") has been assigned to you.");
        } else {
            System.out.println("There are no queued orders. You are available.");
        }
    }

    public void viewDriverReviews(DeliveryPerson driver) {
        List<Review> reviews = driver.getReviews();
        System.out.println("\n--- My Reviews ---");
        if (reviews == null || reviews.isEmpty()) { System.out.println("You have no reviews yet."); return; }
        System.out.println("Average Rating: " + driver.getAverageRating());
        for (Review review : reviews) {
            System.out.printf("Review ID: %d | Rating: %d | Comment: %s | Reviewer: %s%n",
                    review.getReviewID(), review.getRating(), review.getComment(),
                    review.getCustomer() != null ? review.getCustomer().getName() : "Unknown");
        }
    }
}
