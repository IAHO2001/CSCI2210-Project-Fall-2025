import java.util.ArrayList;
import java.util.List;

/**
 * DeliveryPerson
 *
 * Represents a delivery driver.
 */
public class DeliveryPerson extends Person {

    private int driverID;
    private String password;
    private String vehicleType;
    private String availability;
    private List<Order> assignedOrders;
    private FoodDeliverySystem system;
    private List<Review> reviews;

    public DeliveryPerson(String name, String email, String phoneNumber, String password,
                          String vehicleType, String availability, FoodDeliverySystem system) {
        super(name, email, phoneNumber);
        this.driverID = IDgenerator.generateDeliveryPersonID();
        this.password = password;
        this.vehicleType = vehicleType;
        this.availability = availability;
        this.system = system;
        this.assignedOrders = new ArrayList<>();
        this.reviews = new ArrayList<>();
    }

    public int getDriverID() { return driverID; }
    public String getPassword() { return password; }
    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String type) { this.vehicleType = type; }
    public String getAvailability() { return availability; }
    public void setAvailability(String availability) { this.availability = availability; }
    public List<Order> getAssignedOrders() { return assignedOrders; }

    public void assignOrder(Order order) {
        if (order != null) assignedOrders.add(order);
    }

    public void removeAssignedOrder(Order order) {
        assignedOrders.remove(order);
    }

    public FoodDeliverySystem getSystem() { return system; }

    public void addReview(Review r) { if (r != null) reviews.add(r); }
    public List<Review> getReviews() { return reviews; }

    public double getAverageRating() {
        if (reviews == null || reviews.isEmpty()) return 0.0;
        int sum = 0;
        for (Review r : reviews) sum += r.getRating();
        return (double) sum / reviews.size();
    }
}
