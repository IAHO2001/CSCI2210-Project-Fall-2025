import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * CustomerMenuManager
 *
 * Handles customer-side operations such as browsing restaurants,
 * viewing order history, and leaving reviews.
 */
public class CustomerMenuManager {
    private FoodDeliverySystem system;
    private Scanner in;
    private User loggedInCustomer;

    public CustomerMenuManager(FoodDeliverySystem system, User customer) {
        this.system = system;
        this.in = new Scanner(System.in);
        this.loggedInCustomer = customer;
    }

    public void browseRestaurants() {
        List<Restaurant> restaurants = system.getRestaurants();
        if (restaurants == null || restaurants.isEmpty()) {
            System.out.println("No restaurants available.");
            return;
        }

        int option = 0;
        do {
            System.out.println("\n--- Restaurants ---");
            for (int i = 0; i < restaurants.size(); i++) {
                System.out.printf("%d. %s%n", i + 1, restaurants.get(i).getName());
            }
            System.out.println((restaurants.size() + 1) + ". Back to Customer Menu");
            System.out.print("Select a restaurant: ");

            if (in.hasNextInt()) {
                option = in.nextInt(); in.nextLine();
                if (option >= 1 && option <= restaurants.size()) {
                    new RestaurantSubMenu(loggedInCustomer, system, restaurants.get(option - 1)).showMenu(restaurants.get(option - 1));
                } else if (option == restaurants.size() + 1) {
                    System.out.println("Returning to Customer Menu...");
                } else {
                    System.out.println("Invalid option.");
                }
            } else {
                in.nextLine();
                System.out.println("Invalid input. Please enter a number.");
            }
        } while (option != restaurants.size() + 1);
    }

    public void viewOrderHistory() {
        List<Order> orders = system.getOrders();
        boolean hasOrders = false;
        System.out.println("\n--- Your Order History ---");
        for (Order order : orders) {
            if (order.getCustomer() != null && order.getCustomer().equals(loggedInCustomer)) {
                hasOrders = true;
                System.out.println("Order ID: " + order.getOrderID());
                System.out.println("Restaurant: " + order.getRestaurant().getName());
                System.out.println("Items:");
                for (MenuItem item : order.getItems()) {
                    System.out.println(" - " + item.getName() + " ($" + String.format("%.2f", item.getPrice()) + ")");
                }
                System.out.println("Total: $" + String.format("%.2f", order.getTotalPrice()));
                System.out.println("Status: " + order.getStatus());
                DeliveryPerson driver = order.getDeliveryPerson();
                System.out.println("Delivery Driver: " + (driver != null ? driver.getName() : "Not assigned"));
                System.out.println("-----------------------------");
            }
        }
        if (!hasOrders) {
            System.out.println("You have not placed any orders yet.");
        }
    }

    public void leaveReview(User customer) {
        List<Order> orders = system.getOrders();
        List<Order> customerOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getCustomer() != null && order.getCustomer().equals(customer) && "Completed".equalsIgnoreCase(order.getStatus())) {
                customerOrders.add(order);
            }
        }
        if (customerOrders.isEmpty()) {
            System.out.println("You have no completed orders to leave a review for.");
            return;
        }

        System.out.println("\n--- Your Completed Orders ---");
        for (int i = 0; i < customerOrders.size(); i++) {
            Order order = customerOrders.get(i);
            System.out.printf("%d. Order ID: %d | Restaurant: %s | Total: $%.2f%n",
                    i + 1, order.getOrderID(), order.getRestaurant().getName(), order.getTotalPrice());
        }

        System.out.print("Select an order to leave a review for: ");
        if (!in.hasNextInt()) { in.nextLine(); System.out.println("Invalid input."); return; }
        int choice = in.nextInt(); in.nextLine();
        if (choice < 1 || choice > customerOrders.size()) { System.out.println("Invalid selection."); return; }
        Order selectedOrder = customerOrders.get(choice - 1);
        Restaurant restaurant = selectedOrder.getRestaurant();
        DeliveryPerson driver = selectedOrder.getDeliveryPerson();

        System.out.println("1. Leave review for restaurant");
        System.out.println("2. Leave review for delivery driver");
        System.out.println("3. Leave review for both");
        System.out.print("Choose an option: ");
        if (!in.hasNextInt()) { in.nextLine(); System.out.println("Invalid input."); return; }
        int reviewOption = in.nextInt(); in.nextLine();

        System.out.print("Enter your rating (1-5): ");
        if (!in.hasNextInt()) { in.nextLine(); System.out.println("Invalid input for rating."); return; }
        int rating = in.nextInt(); in.nextLine();

        System.out.print("Enter your comment: ");
        String comment = in.nextLine();

        if (reviewOption == 1) {
            Review review = new Review(customer, restaurant, rating, comment);
            restaurant.addReview(review);
            system.addReview(review);
            System.out.println("Thank you! Your review for the restaurant has been submitted.");
        } else if (reviewOption == 2) {
            if (driver == null) { System.out.println("No driver assigned for this order."); return; }
            Review review = new Review(customer, driver, rating, comment);
            driver.addReview(review);
            system.addReview(review);
            System.out.println("Thank you! Your review for the delivery driver has been submitted.");
        } else if (reviewOption == 3) {
            if (driver == null) { System.out.println("No driver assigned for this order."); return; }
            Review restReview = new Review(customer, restaurant, rating, comment);
            Review driverReview = new Review(customer, driver, rating, comment);
            restaurant.addReview(restReview);
            driver.addReview(driverReview);
            system.addReview(restReview);
            system.addReview(driverReview);
            System.out.println("Thank you! Your reviews for both restaurant and driver have been submitted.");
        } else {
            System.out.println("Invalid option.");
        }
    }
}
