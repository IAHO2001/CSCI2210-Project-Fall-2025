import java.util.Scanner;

/**
 * AdminMenu - console UI for admin actions.
 *
 * Delegates behavior to AdminMenuManager for CRUD operations and views.
 */
public class AdminMenu implements MenuInterface {
    private AdminMenuManager manager;

    public AdminMenu(FoodDeliverySystem system) {
        this.manager = new AdminMenuManager(system);
    }

    @Override
    public void showMenu() {
        System.out.println("No admin logged in.");
    }

    public void showMenu(Admin admin) {
        Scanner in = new Scanner(System.in);
        int option = 0;

        do {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add Delivery Driver");
            System.out.println("2. Edit Delivery Driver");
            System.out.println("3. Remove Delivery Driver");
            System.out.println("4. View All Drivers");
            System.out.println("5. View All Users");
            System.out.println("6. View All Orders");
            System.out.println("7. Manage Restaurants");
            System.out.println("8. Logout");
            System.out.print("Choose an option: ");

            if (in.hasNextInt()) {
                option = in.nextInt();
                in.nextLine();

                switch (option) {
                    case 1 -> manager.addDeliveryDriver();
                    case 2 -> manager.editDeliveryDriver();
                    case 3 -> manager.removeDriver();
                    case 4 -> manager.viewDeliveryDrivers();
                    case 5 -> manager.viewAllUsers();
                    case 6 -> manager.viewAllOrders();
                    case 7 -> showRestaurantManagementMenu();
                    case 8 -> System.out.println("Logging out...");
                    default -> System.out.println("Invalid option.");
                }
            } else {
                in.nextLine();
                System.out.println("\nInvalid input. Please enter a Number.");
            }
        } while (option != 8);
    }

    private void showRestaurantManagementMenu() {
        Scanner in = new Scanner(System.in);
        int option = 0;
        do {
            System.out.println("\n--- Restaurant Management ---");
            System.out.println("1. Add Restaurant");
            System.out.println("2. Edit Restaurant");
            System.out.println("3. Remove Restaurant");
            System.out.println("4. View All Restaurants");
            System.out.println("5. Back");
            System.out.print("Choose an option: ");

            if (in.hasNextInt()) {
                option = in.nextInt();
                in.nextLine();

                switch (option) {
                    case 1 -> manager.addRestaurant();
                    case 2 -> manager.editRestaurant();
                    case 3 -> manager.removeRestaurant();
                    case 4 -> manager.viewAllRestaurants();
                    case 5 -> System.out.println("Returning to Admin Menu...");
                    default -> System.out.println("Invalid option.");
                }
            } else {
                in.nextLine();
                System.out.println("Invalid input.");
            }
        } while (option != 5);
    }
}
