/**
 * CreditCardPayment
 *
 * Simple credit card payment simulation for this project.
 */
public class CreditCardPayment extends Payment {

    private String cardNumber;
    private String cardHolder;
    private String expiry;

    public CreditCardPayment(double amount, String cardNumber, String cardHolder, String expiry) {
        super(amount);
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
        this.expiry = expiry;
    }

    @Override
    public boolean processPayment() {
        System.out.println("Processing credit card payment...");
        // In real project you'd validate card, call gateway, etc.
        return true;
    }
}

