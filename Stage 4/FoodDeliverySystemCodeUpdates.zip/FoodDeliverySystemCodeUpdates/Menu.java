import java.util.ArrayList;
import java.util.List;

/**
 * Menu
 *
 * Represents a restaurant's menu containing multiple MenuItems.
 * Includes compatibility aliases (addMenuItem/removeMenuItem) used in older code.
 */
public class Menu {

    private Restaurant restaurant;
    private List<MenuItem> items;

    public Menu(Restaurant restaurant) {
        this.restaurant = restaurant;
        this.items = new ArrayList<>();
    }

    public void addItem(MenuItem item) {
        if (item != null) items.add(item);
    }

    public void removeItem(MenuItem item) {
        items.remove(item);
    }

    // compatibility aliases
    public void addMenuItem(MenuItem item) { addItem(item); }
    public void removeMenuItem(MenuItem item) { removeItem(item); }

    public List<MenuItem> getItems() { return items; }

    @Override
    public String toString() {
        return restaurant.getName() + " Menu (" + items.size() + " items)";
    }
}
