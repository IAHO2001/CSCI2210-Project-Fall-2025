import java.util.Scanner;

/**
 * DriverMenu - console UI for a delivery driver.
 */
public class DriverMenu implements MenuInterface {
    private DriverMenuManager manager;

    public DriverMenu() { this.manager = new DriverMenuManager(); }

    public void showMenu(DeliveryPerson driver) {
        Scanner in = new Scanner(System.in);
        int option = -1;
        do {
            System.out.println("\n--- Delivery Driver Menu ---");
            System.out.println("1. View Assigned Orders");
            System.out.println("2. Mark Order as Completed");
            System.out.println("3. View My Reviews");
            System.out.println("4. Logout");
            System.out.print("Choose an option: ");
            if (in.hasNextInt()) {
                option = in.nextInt(); in.nextLine();
                switch (option) {
                    case 1 -> manager.viewAssignedOrders(driver);
                    case 2 -> manager.completeOrder(driver);
                    case 3 -> manager.viewDriverReviews(driver);
                    case 4 -> System.out.println("Logging out...");
                    default -> System.out.println("Invalid option. Try again.");
                }
            } else {
                in.nextLine();
                System.out.println("\nInvalid input. Please enter a number.");
            }
        } while (option != 4);
    }

    @Override
    public void showMenu() { System.out.println("No driver logged in."); }
}
