/**
 * CashPayment
 *
 * Cash-on-delivery payment type.
 */
public class CashPayment extends Payment {
    public CashPayment(double amount) {
        super(amount);
    }

    @Override
    public boolean processPayment() {
        System.out.println("Cash will be collected on delivery.");
        return true;
    }
}
