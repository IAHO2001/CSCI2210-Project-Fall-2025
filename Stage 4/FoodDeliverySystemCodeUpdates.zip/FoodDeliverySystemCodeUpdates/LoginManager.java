import java.util.List;

/**
 * LoginManager
 *
 * Handles authentication for Users, Admins, and DeliveryPersonnel.
 * Includes compatibility wrapper methods `loginUser`, `loginAdmin`, `loginDriver`.
 */
public class LoginManager {

    public User authenticateUser(String email, String password, List<User> users) {
        if (email == null || password == null) return null;
        for (User u : users) {
            if (u.getEmail().equalsIgnoreCase(email) && u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }

    public Admin authenticateAdmin(String email, String pass, List<Admin> admins) {
        if (email == null || pass == null) return null;
        for (Admin a : admins) {
            if (a.getEmail().equalsIgnoreCase(email) && a.getPassword().equals(pass)) {
                return a;
            }
        }
        return null;
    }

    public DeliveryPerson authenticateDriver(String email, String pass, List<DeliveryPerson> drivers) {
        if (email == null || pass == null) return null;
        for (DeliveryPerson d : drivers) {
            if (d.getEmail().equalsIgnoreCase(email) && d.getPassword().equals(pass)) {
                return d;
            }
        }
        return null;
    }

    // Backwards-compatible wrappers
    public User loginUser(String email, String password, List<User> users) {
        return authenticateUser(email, password, users);
    }

    public Admin loginAdmin(String email, String password, List<Admin> admins) {
        return authenticateAdmin(email, password, admins);
    }

    public DeliveryPerson loginDriver(String email, String password, List<DeliveryPerson> drivers) {
        return authenticateDriver(email, password, drivers);
    }
}
