/**
 * Main - program entry point.
 */
public class Main {
    public static void main(String[] args) {
        FoodDeliverySystem system = new FoodDeliverySystem();
        try {
            LoadSystem.loadSystem(system);
        } catch (Exception e) {
            System.out.println("Warning: LoadSystem not run or failed: " + e.getMessage());
        }
        MainMenu mainMenu = new MainMenu(system);
        mainMenu.showMenu();
    }
}
