import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * FoodDeliverySystem
 *
 * Central storage & helper operations for the app.
 */
public class FoodDeliverySystem {

    private List<User> users;
    private List<Restaurant> restaurants;
    private List<Order> orders;
    private List<DeliveryPerson> deliveryPersonnel;
    private List<Admin> admins;
    private LoginManager loginManager;
    private List<Review> reviews;
    private Queue<Order> pendingOrders;

    public FoodDeliverySystem() {
        this.users = new ArrayList<>();
        this.restaurants = new ArrayList<>();
        this.orders = new ArrayList<>();
        this.deliveryPersonnel = new ArrayList<>();
        this.admins = new ArrayList<>();
        this.loginManager = new LoginManager();
        this.reviews = new ArrayList<>();
        this.pendingOrders = new LinkedList<>();
    }

    public void addUser(User user) { if (user != null) users.add(user); }
    public void addRestaurant(Restaurant restaurant) { if (restaurant != null) restaurants.add(restaurant); }
    public void addOrder(Order order) { if (order != null) orders.add(order); }
    public void addDeliveryPerson(DeliveryPerson driver) { if (driver != null) deliveryPersonnel.add(driver); }
    public void addAdmin(Admin admin) { if (admin != null) admins.add(admin); }
    public void addReview(Review review) { if (review != null) reviews.add(review); }

    public List<User> getUsers() { return users; }
    public List<Restaurant> getRestaurants() { return restaurants; }
    public List<Order> getOrders() { return orders; }
    public List<DeliveryPerson> getDeliveryPersonnel() { return deliveryPersonnel; }
    public List<Admin> getAdmins() { return admins; }
    public LoginManager getLoginManager() { return loginManager; }
    public List<Review> getReviews() { return reviews; }
    public Queue<Order> getPendingOrders() { return pendingOrders; }

    /**
     * Removes a restaurant.
     */
    public boolean removeRestaurant(Restaurant r) {
        return restaurants.remove(r);
    }

    /**
     * Assigns an available delivery person to an order. If none available, queue the order.
     *
     * @param order order needing assignment
     * @return the assigned DeliveryPerson, or null if queued
     */
    public DeliveryPerson assignDeliveryPerson(Order order) {
        for (DeliveryPerson driver : deliveryPersonnel) {
            if (driver.getAvailability().equalsIgnoreCase("Available")) {
                driver.assignOrder(order);
                order.assignDeliveryPerson(driver);
                driver.setAvailability("On Delivery");
                return driver;
            }
        }
        pendingOrders.add(order);
        return null;
    }

    /**
     * Searches for a restaurant by name (case-insensitive).
     */
    public Restaurant searchRestaurant(String name) {
        if (name == null) return null;
        for (Restaurant r : restaurants) {
            if (r.getName().equalsIgnoreCase(name)) return r;
        }
        return null;
    }

    /**
     * Searches users by email.
     */
    public User searchUser(String email) {
        if (email == null) return null;
        for (User u : users) {
            if (u.getEmail().equalsIgnoreCase(email)) return u;
        }
        return null;
    }
}
