import java.util.List;
import java.util.Scanner;

/**
 * AdminMenuManager
 *
 * Admin-side operations: manage drivers, users, orders, and restaurants.
 */
public class AdminMenuManager {
    private FoodDeliverySystem system;
    private Scanner in;

    public AdminMenuManager(FoodDeliverySystem system) {
        this.system = system;
        this.in = new Scanner(System.in);
    }

    // -----------------------
    // Delivery driver CRUD
    // -----------------------
    public void addDeliveryDriver() {
        System.out.print("Enter driver name: ");
        String name = in.nextLine();
        System.out.print("Enter driver email: ");
        String email = in.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = in.nextLine();
        System.out.print("Enter password: ");
        String password = in.nextLine();
        System.out.print("Enter vehicle type: ");
        String vehicleType = in.nextLine();
        System.out.print("Enter availability: ");
        String availability = in.nextLine();

        DeliveryPerson d = new DeliveryPerson(name, email, phoneNumber, password, vehicleType, availability, system);
        system.addDeliveryPerson(d);
        System.out.println("Driver added.");

        if (!system.getPendingOrders().isEmpty()) {
            Order nextOrder = system.getPendingOrders().poll();
            system.assignDeliveryPerson(nextOrder);
            System.out.println(d.getName() + " has been assigned to a pending order. Order ID: " + nextOrder.getOrderID());
        }
    }

    public void removeDriver() {
        List<DeliveryPerson> drivers = system.getDeliveryPersonnel();
        if (drivers.isEmpty()) {
            System.out.println("No drivers available to remove.");
            return;
        }
        System.out.println("--- Delivery Drivers ---");
        for (int i = 0; i < drivers.size(); i++) {
            DeliveryPerson d = drivers.get(i);
            System.out.printf("%d. %s | Email: %s | Vehicle: %s | Availability: %s%n",
                    i + 1, d.getName(), d.getEmail(), d.getVehicleType(), d.getAvailability());
        }
        System.out.print("Select a driver to remove: ");
        if (!in.hasNextInt()) {
            in.nextLine();
            System.out.println("Invalid input. Please enter a number.");
            return;
        }
        int choice = in.nextInt(); in.nextLine();
        if (choice < 1 || choice > drivers.size()) {
            System.out.println("Invalid selection.");
            return;
        }
        DeliveryPerson toRemove = drivers.get(choice - 1);
        if (!toRemove.getAssignedOrders().isEmpty()) {
            System.out.println("Cannot remove this driver. They currently have active deliveries.");
            return;
        }
        drivers.remove(toRemove);
        System.out.println("Driver " + toRemove.getName() + " removed.");
    }

    public void viewDeliveryDrivers() {
        List<DeliveryPerson> drivers = system.getDeliveryPersonnel();
        if (drivers.isEmpty()) {
            System.out.println("No registered drivers.");
            return;
        }
        for (DeliveryPerson d : drivers) {
            System.out.println(d.getName() + " | " + d.getPhoneNumber() + " | " + d.getAvailability() + " | " + d.getAverageRating());
        }
    }

    public void editDeliveryDriver() {
        List<DeliveryPerson> drivers = system.getDeliveryPersonnel();
        if (drivers.isEmpty()) { System.out.println("No drivers available."); return; }
        System.out.println("--- Delivery Drivers ---");
        for (int i = 0; i < drivers.size(); i++) {
            DeliveryPerson d = drivers.get(i);
            System.out.printf("%d. %s | Email: %s | Vehicle: %s | Availability: %s%n",
                    i + 1, d.getName(), d.getEmail(), d.getVehicleType(), d.getAvailability());
        }
        int choice = -1;
        while (true) {
            System.out.print("Select driver to edit by number: ");
            if (in.hasNextInt()) {
                choice = in.nextInt(); in.nextLine();
                if (choice >= 1 && choice <= drivers.size()) break;
                else System.out.println("Invalid selection.");
            } else {
                in.nextLine();
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        DeliveryPerson driver = drivers.get(choice - 1);
        System.out.print("Enter new name (leave blank to keep current): ");
        String name = in.nextLine();
        if (!name.isBlank()) driver.setName(name);
        System.out.print("Enter new vehicle type (leave blank to keep current): ");
        String vehicle = in.nextLine();
        if (!vehicle.isBlank()) driver.setVehicleType(vehicle);
        System.out.print("Enter new availability (leave blank to keep current): ");
        String availability = in.nextLine();
        if (!availability.isBlank()) driver.setAvailability(availability);
        System.out.println("Driver updated successfully!");
    }

    // -----------------------
    // Users & Orders views
    // -----------------------
    public void viewAllUsers() {
        if (system.getUsers().isEmpty()) {
            System.out.println("There are no users in this system.");
            return;
        }
        System.out.println("--- All Users ---");
        for (User u : system.getUsers()) {
            System.out.printf("Name: %s | Email: %s%n", u.getName(), u.getEmail());
        }
    }

    public void viewAllOrders() {
        List<Order> orders = system.getOrders();
        if (orders.isEmpty()) { System.out.println("No orders found."); return; }
        System.out.println("--- All Orders ---");
        for (Order order : orders) {
            String customerName = (order.getCustomer() != null) ? order.getCustomer().getName() : "Unknown Customer";
            System.out.printf("Order ID: %d | Customer: %s | Total: $%.2f | Status: %s%n",
                    order.getOrderID(), customerName, order.getTotalPrice(), order.getStatus());
        }
    }

    // -----------------------
    // Restaurant CRUD
    // -----------------------
    public void addRestaurant() {
        System.out.print("Enter restaurant name: ");
        String name = in.nextLine();
        System.out.print("Enter address: ");
        String address = in.nextLine();
        System.out.print("Enter phone number: ");
        String phone = in.nextLine();
        Restaurant r = new Restaurant(name, address, phone);
        system.addRestaurant(r);
        System.out.println("Restaurant added: " + r.getName());
    }

    public void viewAllRestaurants() {
        List<Restaurant> restaurants = system.getRestaurants();
        if (restaurants.isEmpty()) { System.out.println("No restaurants available."); return; }
        System.out.println("\n--- Restaurants ---");
        for (int i = 0; i < restaurants.size(); i++) {
            Restaurant r = restaurants.get(i);
            System.out.printf("%d. %s | %s | Phone: %s | Avg Rating: %.2f%n",
                    i + 1, r.getName(), r.getAddress(), r.getPhoneNumber(), r.getAverageRating());
        }
    }

    public void editRestaurant() {
        List<Restaurant> restaurants = system.getRestaurants();
        if (restaurants.isEmpty()) { System.out.println("No restaurants available."); return; }
        System.out.println("\n--- Edit Restaurant ---");
        for (int i = 0; i < restaurants.size(); i++) {
            System.out.printf("%d. %s%n", i + 1, restaurants.get(i).getName());
        }
        System.out.print("Select a restaurant to edit: ");
        if (!in.hasNextInt()) {
            in.nextLine(); System.out.println("Invalid input.");
            return;
        }
        int idx = in.nextInt(); in.nextLine();
        if (idx < 1 || idx > restaurants.size()) { System.out.println("Invalid selection."); return; }
        Restaurant r = restaurants.get(idx - 1);
        System.out.print("Enter new name (leave blank to keep): ");
        String name = in.nextLine();
        if (!name.isBlank()) r.setName(name);
        System.out.print("Enter new address (leave blank to keep): ");
        String address = in.nextLine();
        if (!address.isBlank()) r.setAddress(address);
        System.out.print("Enter new phone (leave blank to keep): ");
        String phone = in.nextLine();
        if (!phone.isBlank()) r.setPhoneNumber(phone);
        System.out.println("Restaurant updated.");
    }

    public void removeRestaurant() {
        List<Restaurant> restaurants = system.getRestaurants();
        if (restaurants.isEmpty()) { System.out.println("No restaurants available."); return; }
        System.out.println("\n--- Remove Restaurant ---");
        for (int i = 0; i < restaurants.size(); i++) {
            System.out.printf("%d. %s%n", i + 1, restaurants.get(i).getName());
        }
        System.out.print("Select a restaurant to remove: ");
        if (!in.hasNextInt()) { in.nextLine(); System.out.println("Invalid input."); return; }
        int idx = in.nextInt(); in.nextLine();
        if (idx < 1 || idx > restaurants.size()) { System.out.println("Invalid selection."); return; }
        Restaurant r = restaurants.get(idx - 1);
        system.removeRestaurant(r);
        System.out.println("Removed restaurant: " + r.getName());
    }
}
