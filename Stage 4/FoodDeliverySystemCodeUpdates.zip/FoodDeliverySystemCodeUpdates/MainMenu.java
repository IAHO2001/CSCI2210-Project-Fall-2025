import java.util.Scanner;

/**
 * MainMenu - top-level console menu.
 */
public class MainMenu implements MenuInterface {
    private FoodDeliverySystem system;
    private AdminMenu adminMenu;
    private DriverMenu driverMenu;

    public MainMenu(FoodDeliverySystem system) {
        this.system = system;
        this.adminMenu = new AdminMenu(system);
        this.driverMenu = new DriverMenu();
    }

    @Override
    public void showMenu() {
        Scanner in = new Scanner(System.in);
        int option = 0;
        do {
            System.out.println("\n=== Food Delivery System ===");
            System.out.println("1. Login as Admin");
            System.out.println("2. Login as Customer");
            System.out.println("3. Login as Delivery Driver");
            System.out.println("4. Create a New Customer");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            if (in.hasNextInt()) {
                option = in.nextInt(); in.nextLine();
                switch (option) {
                    case 1 -> loginAdmin();
                    case 2 -> loginCustomer();
                    case 3 -> loginDriver();
                    case 4 -> createNewCustomer();
                    case 5 -> System.out.println("Exiting. Goodbye!");
                    default -> System.out.println("Invalid option. Try again.");
                }
            } else {
                in.nextLine();
                System.out.println("Invalid input. Please enter a Number.");
            }
        } while (option != 5);
    }

    private void loginAdmin() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter admin email: ");
        String email = in.nextLine();
        System.out.print("Enter password: ");
        String password = in.nextLine();
        Admin admin = system.getLoginManager().authenticateAdmin(email, password, system.getAdmins());
        if (admin != null) adminMenu.showMenu(admin);
        else System.out.println("Invalid Email/Password");
    }

    private void loginDriver() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter driver email: ");
        String email = in.nextLine();
        System.out.print("Enter password: ");
        String password = in.nextLine();
        DeliveryPerson driver = system.getLoginManager().authenticateDriver(email, password, system.getDeliveryPersonnel());
        if (driver != null) driverMenu.showMenu(driver);
        else System.out.println("Invalid Email/Password");
    }

    private void loginCustomer() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter email: ");
        String email = in.nextLine();
        System.out.print("Enter password: ");
        String password = in.nextLine();
        User customer = system.getLoginManager().authenticateUser(email, password, system.getUsers());
        if (customer != null) {
            CustomerMenu customerMenu = new CustomerMenu(system, customer);
            customerMenu.showMenu(customer);
        } else {
            System.out.println("Invalid email/password.");
        }
    }

    private void createNewCustomer() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter customer name: ");
        String name = in.nextLine();
        System.out.print("Enter email: ");
        String email = in.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = in.nextLine();
        System.out.print("Enter password: ");
        String password = in.nextLine();
        System.out.print("Enter address: ");
        String address = in.nextLine();
        User newUser = new User(name, email, phoneNumber, password, address);
        system.addUser(newUser);
        System.out.println("Customer account created.");
    }
}
