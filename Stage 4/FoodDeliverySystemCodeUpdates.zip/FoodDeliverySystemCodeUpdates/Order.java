import java.util.ArrayList;
import java.util.List;

/**
 * Order
 *
 * Represents a customer's order.
 * Includes compatibility overloads for Cart-based construction and aliases.
 */
public class Order {

    private int orderID;
    private User customer;
    private Restaurant restaurant;
    private List<MenuItem> items;
    private double totalPrice;
    private DeliveryPerson assignedDriver;
    private String status;
    private Cart cartReference;

    public Order(User customer, Restaurant restaurant, List<MenuItem> items) {
        this.orderID = IDgenerator.generateOrderID();
        this.customer = customer;
        this.restaurant = restaurant;
        this.items = new ArrayList<>(items != null ? items : new ArrayList<>());
        this.totalPrice = calculateTotal();
        this.status = "Pending";
    }

    // compatibility: constructor that accepts a Cart
    public Order(User customer, Restaurant restaurant, Cart cart) {
        this.orderID = IDgenerator.generateOrderID();
        this.customer = customer;
        this.restaurant = restaurant;
        this.items = new ArrayList<>(cart != null ? cart.getItems() : new ArrayList<>());
        this.totalPrice = calculateTotal();
        this.status = "Pending";
        this.cartReference = cart;
    }

    private double calculateTotal() {
        double sum = 0;
        if (items != null) {
            for (MenuItem m : items) sum += m.getPrice();
        }
        return sum;
    }

    public int getOrderID() { return orderID; }
    public User getCustomer() { return customer; }
    public Restaurant getRestaurant() { return restaurant; }
    public List<MenuItem> getItems() { return items; }
    public double getTotalPrice() { return totalPrice; }
    public String getStatus() { return status; }
    public void setStatus(String newStatus) { this.status = newStatus; }

    public DeliveryPerson getAssignedDriver() { return assignedDriver; }
    public DeliveryPerson getDeliveryPerson() { return getAssignedDriver(); } // compatibility

    public void assignDeliveryPerson(DeliveryPerson driver) {
        this.assignedDriver = driver;
    }

    public void setDeliveryPerson(DeliveryPerson d) { assignDeliveryPerson(d); } // compatibility

    public Cart getCart() {
        if (cartReference != null) return cartReference;
        Cart c = new Cart(customer);
        for (MenuItem m : items) c.addItem(m);
        return c;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderID + ", Total: $" + totalPrice + ", Status: " + status;
    }
}
