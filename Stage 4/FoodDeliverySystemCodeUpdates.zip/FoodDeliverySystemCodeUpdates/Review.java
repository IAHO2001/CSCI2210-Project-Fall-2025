/**
 * Review
 *
 * Represents a review left by a customer for a restaurant and/or a delivery driver.
 * Includes compatibility aliases for older method names.
 */
public class Review {

    private int reviewID;
    private User customer;
    private Restaurant restaurant;
    private DeliveryPerson driver;   // optional
    private int rating;              // 1–5 stars
    private String comment;

    public Review(User customer, Restaurant restaurant, int rating, String comment) {
        this.reviewID = IDgenerator.generateReviewID();
        this.customer = customer;
        this.restaurant = restaurant;
        this.rating = rating;
        this.comment = comment;
        this.driver = null;
    }

    public Review(User customer, DeliveryPerson driver, int rating, String comment) {
        this.reviewID = IDgenerator.generateReviewID();
        this.customer = customer;
        this.driver = driver;
        this.rating = rating;
        this.comment = comment;
        this.restaurant = null;
    }

    public Review(User customer, Restaurant restaurant, DeliveryPerson driver, int rating, String comment) {
        this.reviewID = IDgenerator.generateReviewID();
        this.customer = customer;
        this.restaurant = restaurant;
        this.driver = driver;
        this.rating = rating;
        this.comment = comment;
    }

    public int getReviewID() { return reviewID; }
    public int getReviewid() { return getReviewID(); } // compatibility
    public User getCustomer() { return customer; }
    public User getReviewer() { return getCustomer(); } // compatibility
    public Restaurant getRestaurant() { return restaurant; }
    public DeliveryPerson getDriver() { return driver; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }

    @Override
    public String toString() {
        return "Review ID: " + reviewID + " | Rating: " + rating + " | Comment: " + comment;
    }
}
