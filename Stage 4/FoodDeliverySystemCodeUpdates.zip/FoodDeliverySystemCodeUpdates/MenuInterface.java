/**
 * MenuInterface
 *
 * All menu classes implement this so they provide showMenu().
 */
public interface MenuInterface {
    void showMenu();
}
