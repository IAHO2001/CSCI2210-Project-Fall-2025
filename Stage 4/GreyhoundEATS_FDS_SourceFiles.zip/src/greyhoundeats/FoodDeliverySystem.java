package greyhoundeats;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.LinkedList;

public class FoodDeliverySystem {
    //Instance variables
    private List<User> users;
    private List<Restaurant> restaurants;
    private List<Order> orders;
    private List<DeliveryPerson> deliveryPersonnel;
    private List<Admin> admins;
    private LoginManager loginManager;
    private List<Review> reviews;
    private Queue<Order> pendingOrders;

    /**
     * Constructor
     */
    public FoodDeliverySystem(){
        this.users = new ArrayList<>();
        this.restaurants = new ArrayList<>();
        this.orders = new ArrayList<>();
        this.deliveryPersonnel = new ArrayList<>();
        this.loginManager = new LoginManager();
        this.admins = new ArrayList<>();
        this.reviews = new ArrayList<>();
        this.pendingOrders = new LinkedList<>();
    }

    /**
     * This method adds a user to the list of users
     * @param user
     */
    public void addUser(User user){
        if(user != null) users.add(user);
    }

    /**
     * This method adds a restaurant to the list of restaurants
     * @param restaurant
     */
    public void addRestaurant(Restaurant restaurant){
        if(restaurant != null) restaurants.add(restaurant);
    }

    /**
     * This method adds an order to the list of orders
     * @param order
     */
    public void addOrder(Order order){
        if(order != null) orders.add(order);
    }

    /**
     * This method adds a delivery person to the list of delivery personnel
     * @param driver
     */
    public void addDeliveryPerson(DeliveryPerson driver){
        if(driver != null) deliveryPersonnel.add(driver);
    }

    /**
     * This method returns the lsit of Users
     * @return List<User> user
     */
    public List<User> getUsers(){
        return users;
    }

    /**
     * This method returns the lsit of Restaurants
     * @return List<Restaurant> restaurants
     */
    public List<Restaurant> getRestaurants(){
        if(restaurants.isEmpty()){
            //System.out.println("There are no restaurants.");
            return restaurants;
        } else{
            return restaurants;
        }
    }

    /**
     * This method returns the list of Ordrs
     * @return List<Order> orders
     */
    public List<Order> getOrders(){
        return orders;
    }

    /**
     * This method returns the list of drivers
     * @return List<DeliveryPerson> deliveryPersonnel
     */
    public List<DeliveryPerson> getDeliveryPersonnel(){
        return deliveryPersonnel;
    }

    /**
     * This method returns the Login manager
     * @return LoginManager
     */
    public LoginManager getLoginManager(){
        return loginManager;
    }

    /**
     * This method receieves an object Order and assignes a delivery person to the order .
     * @param order
     * @return DeliveryPerson
     */
    public DeliveryPerson assignDeliveryPerson(Order order){
        for(DeliveryPerson driver : deliveryPersonnel){
            if(driver.getAvailability().equalsIgnoreCase("Available")){
                //driver.assignOrder(order);
                order.assignDeliveryPerson(driver);
                order.setCompletedDriver(driver);
                driver.setAvailability("On Delivery");
                order.setStatus("In-Progress");
                System.out.println("Driver assigned for order " + order.getOrderID() + " to " + driver.getName());
                return driver;
                
            }
        }
        pendingOrders.add(order);
        System.out.println("Order added to que " + order.getOrderID());
        return null;
    }

    /**
     * This method receives a string the name of the restaurant and searches through the list of Restauranats for a match. If the restaurant exist
     * method will return the object Restaurant. If doesn't exist will return null
     * @param name
     * @return Restaurant
     */
    public Restaurant searchRestaurant(String name){
        for(Restaurant restaurant : restaurants){
            if(restaurant.getName().equalsIgnoreCase(name)){
                return restaurant;
            }
        }
        return null;
    }

    /**
     * This method receives a string email and searches through the list of Users for a match. If the user exists the method will return the 
     * object User. IF doesn't exist then will return null
     * @param name
     * @return User
     */
    public User searchUser(String name){
        if (name == null) return null;
        String target = name.trim();
        for (User user : users) {
            if (user.getName() != null && user.getName().trim().equalsIgnoreCase(target)) {
                return user;
            }
        }
        return null;
    }
    
    public MenuItem searchItem(String itemName) {
        if (itemName == null || itemName.trim().isEmpty()) {
            return null;
        }
        
        String target = itemName.replace(" ", "").trim().toLowerCase();

        for (Restaurant r : restaurants) {
            if (r.getMenu() != null) {
                for (MenuItem item : r.getMenu().getItems()) {
                    
                    String normalized = item.getName().replace(" ","").trim().toLowerCase();
                    if (normalized.equals(target)) {
                        return item; 
                    }
                }
            }
        }

        return null; // Not found
    }
    
    public DeliveryPerson searchDriver(String driverName) {
        if (driverName == null || driverName.trim().isEmpty()) {
            return null;
        }

        String search = driverName.trim().toLowerCase();

        for (DeliveryPerson d : deliveryPersonnel) {
            if (d.getName().toLowerCase().equals(search)) {
                return d;  
            }
        }

        return null;
    }



    /**
     * This method returns the list of admins
     * @return List<Admin>
     */
    public List<Admin> getAdmins(){
        return admins;
    }

    /**
     * This method recieves an object admin and adds it to the list of admins
     * @param admin
     */
    public void addAdmin(Admin admin){
        admins.add(admin);
    }

    /**
     * This method recieves object review and adds it to the list of reviews
     * @param review
     */
    public void addReview(Review review){
        reviews.add(review);
    }

    /**
     * This method returns the list of reviews
     * @return List<Review>
     */
    public List<Review> getReviews(){
        return reviews;
    }

    /**
     * This method returns the queue of pending orders
     * @return Queue<Order>
     */
    public Queue<Order> getPendingOrders(){
        return pendingOrders;
    }
}
