/**
 * CashPayment
 *
 * Cash-on-delivery payment type.
 */
package greyhoundeats;

public class CashPayment extends Payment {
    public CashPayment(double amount) {
        super(amount);
    }

    //@Override
    public static boolean processPayment() {
        //System.out.println("Cash will be collected on delivery.");
        return true;
    }
}
