/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package greyhoundeats;
import java.io.*;
import java.util.List;

public class DataManager {

    private static final File DATA_DIR = new File("data");
    private static final String userFile = "users.txt";
    private static final String driverFile = "data/delivery_people.txt";

    private static void ensureDataDir() {
        if (!DATA_DIR.exists()) DATA_DIR.mkdirs();
    }
    
    /**
     * 
     * @param system 
     */
    public static void saveSystem(FoodDeliverySystem system) {
        ensureDataDir();
        saveAllCustomers(system.getUsers());
        saveAllDrivers(system.getDeliveryPersonnel());
        saveAllOrders(system.getOrders());
        saveAllRestaurants(system.getRestaurants());
        saveAllReviews(system.getReviews());
        saveAllMenuItems(system);
        //System.out.println("System data saved successfully.");
    } 
    
    /**
     * 
     * @param customer 
     */
    public static void saveCustomer(User customer) {
        ensureDataDir();
        File file = new File(DATA_DIR, "users.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(formatCustomer(customer));
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 
     * @param customers 
     */
    public static void saveAllCustomers(List<User> customers) {
        ensureDataDir();
        File file = new File(DATA_DIR, "users.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (User customer : customers) {
                writer.write(formatCustomer(customer));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 
     * @param driver 
     */
    public static void saveDriver(DeliveryPerson driver) {
        ensureDataDir();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(driverFile, true))) {
            
            String line = String.join(",",
                    driver.getName(),
                    driver.getEmail(),
                    driver.getPhoneNumber(),
                    driver.getPassword(),
                    driver.getVehicleType(),
                    driver.getAvailability()
            );

            writer.write(line);
            writer.newLine(); 
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error saving driver: " + driver.getName());
        }
    }
    
    /**
     * 
     * @param drivers 
     */
    public static void saveAllDrivers(List<DeliveryPerson> drivers) {
        ensureDataDir();
        File file = new File(DATA_DIR, "delivery_people.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {

            for (DeliveryPerson d : drivers) {
                String line = String.join(",",
                        d.getName(),
                        d.getEmail(),
                        d.getPhoneNumber(),
                        d.getPassword(),
                        d.getVehicleType(),
                        d.getAvailability()
                );

                writer.write(line);
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error saving drivers.");
        }
    }
    
    /**
     * 
     * @param orders 
     */
    public static void saveAllOrders(List<Order> orders) {
        ensureDataDir();
        File file = new File(DATA_DIR, "orders.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (Order order : orders) {
                StringBuilder line = new StringBuilder();

                
                line.append(order.getOrderID()).append(",");
                line.append(order.getCustomer() != null ? order.getCustomer().getName() : "null").append(",");
                line.append(order.getRestaurant().getName()).append(",");
               
                line.append(order.getStatus()).append(",");
               
                line.append(order.getDeliveryPerson() != null ? order.getDeliveryPerson().getName() : "null").append(",");
                
                
                
               
                for (MenuItem item : order.getCart().getItems()) {
                    line.append(item.getName()).append(",");
                    line.append(item.getPrice()).append(",");
                }

                
                if (line.charAt(line.length() - 1) == ',') {
                    line.deleteCharAt(line.length() - 1);
                }

                writer.write(line.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error saving orders.");
        }
    }

    /**
     * 
     * @param restaurants 
     */
    public static void saveAllRestaurants(List<Restaurant> restaurants) {
        ensureDataDir();
        File file = new File(DATA_DIR, "restaurants.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {

            for (Restaurant r : restaurants) {

                List<MenuItem> menu = r.getMenu().getItems();
                List<Review> reviews = r.getReviews();

                StringBuilder line = new StringBuilder();

                line.append(r.getName()).append(",");
                line.append(r.getAddress()).append(",");
                line.append(r.getPhoneNumber()).append(",");
                line.append(menu.size()).append(",");
                line.append(reviews.size());

                
                for (MenuItem item : menu) {
                    line.append(",").append(item.getName());
                    line.append(",").append(item.getPrice());
                }

                
                for (Review review : reviews) {
                    line.append(",").append(review.getReviewer().getName());
                    line.append(",").append(review.getRating());

                    
                    String comment = review.getComment().replace(",", ";");
                    line.append(",").append(comment);
                }

                writer.write(line.toString());
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error saving restaurants.");
        }
    }

    /**
     * 
     * @param reviews 
     */
    public static void saveAllReviews(List<Review> reviews) {
        ensureDataDir();
        File file = new File(DATA_DIR, "reviews.txt");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {

            for (Review review : reviews) {

                String reviewer = review.getReviewer().getName();
                int rating = review.getRating();
                String comment = review.getComment().replace(",", ";");

                String targetName;
                String type;

                if (review.getRestaurant() != null) {
                    targetName = review.getRestaurant().getName();
                    type = "restaurant";
                } else {
                    targetName = review.getDeliveryPerson().getName();
                    type = "driver";
                }

                writer.write(
                    reviewer + "," +
                    targetName + "," +
                    rating + "," +
                    comment + "," +
                    type
                );
                writer.newLine();
            }

        } catch (IOException e) {
            System.err.println("Error saving reviews: " + e.getMessage());
        }
    }
    
    /**
     * 
     * @param system 
     */
    public static void saveAllMenuItems(FoodDeliverySystem system) {
        ensureDataDir();
        File file = new File(DATA_DIR, "menu_items.txt");
        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {

            for (Restaurant r : system.getRestaurants()) {
                for (MenuItem item : r.getMenu().getItems()) {
                    pw.println(r.getName() + "," + item.getName() + "," + item.getPrice());
                }
            }

        } catch (IOException e) {
            System.err.println("Error saving menu_items.txt: " + e.getMessage());
        }
    }
    /**
     * 
     * @param order 
     */
    public static void saveCompletedOrder(Order order) {
        ensureDataDir();
        File file = new File(DATA_DIR, "completedOrders.txt");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {

            StringBuilder line = new StringBuilder();

            line.append(order.getOrderID()).append(",");
            line.append(order.getCustomer() != null ? order.getCustomer().getName() : "null").append(",");
            line.append(order.getRestaurant().getName()).append(",");
            line.append(order.getStatus()).append(",");
            line.append(order.getDeliveryPerson() != null ? order.getDeliveryPerson().getName() : "null").append(",");

            for (MenuItem item : order.getCart().getItems()) {
                line.append(item.getName()).append(",");
                line.append(item.getPrice()).append(",");
            }

            if (line.charAt(line.length() - 1) == ',')
                line.deleteCharAt(line.length() - 1);

            writer.write(line.toString());
            writer.newLine();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }






    /**
     * 
     * @param system 
     */
    public static void loadCustomers(FoodDeliverySystem system) {
        File file = new File(userFile);
        if (!file.exists()) return; 

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length < 5) continue; 

                String username = parts[0].trim();
                String email = parts[1].trim();
                String phone = parts[2].trim();
                String password = parts[3].trim();
                String address = parts[4].trim();

                User customer = new User(username, email, phone, password, address);
                system.addUser(customer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    private static String formatCustomer(User customer) {
        return String.join(",",
                customer.getName(),
                customer.getEmail(),
                customer.getPhoneNumber(),
                customer.getPassword(),
                customer.getAddressUser()
        );
    }
}
