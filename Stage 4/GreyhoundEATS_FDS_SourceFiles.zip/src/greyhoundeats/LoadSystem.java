package greyhoundeats;

//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileReader;
//import java.io.IOException;
import java.io.*;
import java.lang.reflect.Field;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class LoadSystem {

    private static final File DATA_DIR;

    static {
        File jarDir = null;
        try {
            jarDir = new File(LoadSystem.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI()).getParentFile();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        DATA_DIR = new File(jarDir, "data");
        if (!DATA_DIR.exists()) DATA_DIR.mkdirs();
        //System.out.println("Data folder (dynamic files): " + DATA_DIR.getAbsolutePath()); // CHANGED
    }
    
    private static String getDataFolder(){
        return DATA_DIR.getAbsolutePath();
    }
    

    private static File getFile(String filename) {
        return new File(DATA_DIR, filename);
    }

    public static void loadSystem(FoodDeliverySystem system) {
        system.getOrders().clear();
        system.getRestaurants().clear();
        system.getUsers().clear();
        system.getDeliveryPersonnel().clear();
        system.getPendingOrders().clear();
        
        loadAdmins(system);
        loadRestaurants(system);
        loadMenuItems(system);
        loadDeliveryPeople(system);
        loadCustomers(system);
        loadOrders(system);
        loadReviews(system);
        loadCompletedOrders(system);
    }

    private static void loadAdmins(FoodDeliverySystem system) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(
                    LoadSystem.class.getResourceAsStream("/greyhoundeats/data/admins.txt")))) {

            if (br == null) {
                System.out.println("admins.txt not found inside JAR!");
                return;
            }

            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length != 5) continue;

                Admin a = new Admin(p[0], p[1], p[2], p[3], p[4]);
                system.addAdmin(a);
            }

            //System.out.println("Loaded admins from JAR successfully!");
        } catch (IOException e) {
            System.out.println("Error loading admins.txt: " + e.getMessage());
        }
    }



    private static void loadRestaurants(FoodDeliverySystem system) {
        File file = getFile("restaurants.txt");
        if (!file.exists()) return;
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");

                if (p.length < 3) continue; 

                int index = 0;
                String name = p[index++];
                String address = p[index++];
                String phone = p[index++];

                Restaurant r = new Restaurant(name, address, phone);

                system.addRestaurant(r);
            }
            //System.out.println("Restaurants loaded successfully");
        } catch (IOException e) {
            System.err.println("Error loading restaurants.txt: " + e.getMessage());
        }
    }



    private static void loadMenuItems(FoodDeliverySystem system) {
        File file = getFile("menu_items.txt");
        if (!file.exists()) return;
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length != 3) continue;

                String restaurantName = p[0];
                String itemName = p[1];
                double price = Double.parseDouble(p[2]);

                Restaurant r = system.searchRestaurant(restaurantName);
                if (r == null) continue;

                if (r.getMenu() == null)
                    r.setMenu(new Menu(r));

                MenuItem item = new MenuItem(itemName, price);
                r.getMenu().addMenuItem(item);
            }
        } catch (IOException e) {
            System.err.println("Error loading menu_items.txt: " + e.getMessage());
        }
    }

    private static void loadDeliveryPeople(FoodDeliverySystem system) {
        File file = getFile("delivery_people.txt");  
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length != 6) continue;

                DeliveryPerson d = new DeliveryPerson(
                        p[0],  // name
                        p[1],  // email
                        p[2],  // phone
                        p[3],  // password
                        p[4],  // vehicle
                        p[5],  // availability
                        system
                );
                system.addDeliveryPerson(d);
                //System.out.println("load driver driver loadeed " + d.getName() + " " + d.getAvailability());
            }
        } catch (IOException e) {
            System.err.println("Error loading delivery_people.txt: " + e.getMessage());
        }
    }



    private static void loadCustomers(FoodDeliverySystem system) {
        File file = getFile("users.txt");
        if (!file.exists()) return;
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length != 5) continue;

                User u = new User(
                        p[0],   // name
                        p[1],   // email
                        p[2],   // phone
                        p[3],   // password
                        p[4]    // address
                );
                system.addUser(u);
            }
        } catch (IOException e) {
            System.err.println("Error loading customers.txt: " + e.getMessage());
        }
    }


    private static void loadOrders(FoodDeliverySystem system) {
        File file = getFile("orders.txt");
        if (!file.exists()) return;
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            
            system.getPendingOrders().clear();
            system.getOrders().clear();
            
            for (DeliveryPerson driver : system.getDeliveryPersonnel()) {
                driver.getAssignedOrders().clear();
                if (!"Available".equals(driver.getAvailability())) {
                    driver.setAvailability("Available");
                    //System.out.println("load orders driver loadeed " + driver.getName() + " " + driver.getAvailability());
                }
            }
            

            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");

                if (p.length < 5) continue;

                int index = 0;
                int orderID = Integer.parseInt(p[index++]);
                String customerName = p[index++];
                String restaurantName = p[index++];
                String status = p[index++];
                String driverName = p[index++];

                User customer = customerName.equals("null") ? null : system.searchUser(customerName);
                Restaurant restaurant = system.searchRestaurant(restaurantName);

                Cart cart = new Cart(customer);
                while (index + 1 < p.length) { 
                    String itemName = p[index++];
                    double itemPrice = Double.parseDouble(p[index++]);
                    MenuItem item = new MenuItem(itemName, itemPrice);
                    cart.addItem(item);
                }
                
                Order order = new Order(customer, restaurant, cart);
                order.setStatus(status);

                // Assign driver if exists
                if (!driverName.equals("null") && order.getStatus().equalsIgnoreCase("In-Progress")) {
                    //System.out.println("Order had previously been assinged");
                    DeliveryPerson driver = system.searchDriver(driverName);
                    if (driver != null) {
                        order.assignDeliveryPerson(driver); 
                        order.setCompletedDriver(driver);
                        driver.setAvailability("On Delivery");
                        //driver.assignOrder(order);          
                    }
                } else{
                    if(status.equalsIgnoreCase("pending")){
                       system.assignDeliveryPerson(order); 
                    } else if(order.getStatus().equalsIgnoreCase("Completed") && !driverName.equals("null")){
                        DeliveryPerson driver = system.searchDriver(driverName);
                        order.setCompletedDriver(driver);
                    }
                }
                system.addOrder(order);
                customer.addOrder(order);
            }

        } catch (IOException e) {
            System.err.println("Error loading orders.txt: " + e.getMessage());
        }
    }

    
    public static List<Order> loadCompletedOrders(FoodDeliverySystem system) {
        File file = getFile("completedOrders.txt");
        List<Order> completedOrders = new ArrayList<>();

        if (!file.exists()) {
            System.out.println("No completedOrders.txt found — creating a new one.");
            return completedOrders;  
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] data = line.split(",");

                int index = 0;

                int orderID = Integer.parseInt(data[index++]);
                String customerName = data[index++].trim();
                String restaurantName = data[index++].trim();
                String status = data[index++].trim();
                String driverName = data[index++].trim();

                
                User customer = system.searchUser(customerName);
                Restaurant restaurant = system.searchRestaurant(restaurantName);
                DeliveryPerson completedDriver = system.searchDriver(driverName);

                if (restaurant == null) {
                    //System.out.println("Restaurant not found for completed order: " + restaurantName);
                    continue; 
                }

                // ---- Load Menu Items (Cart) ----
                Cart cart = new Cart(customer);
                while (index < data.length - 1) {
                    String itemName = data[index++].trim();
                    double itemPrice = Double.parseDouble(data[index++].trim());
                    cart.addItem(new MenuItem(itemName, itemPrice));
                }

                
                Order order = new Order(customer, restaurant, cart);
                order.setStatus(status);
                order.setCompletedDriver(completedDriver);


                if (!driverName.equals("null") && completedDriver != null) {
                    order.setCompletedDriver(completedDriver);
                }

                completedOrders.add(order);
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error loading completed orders.");
        }

        return completedOrders;
    }




    private static void loadReviews(FoodDeliverySystem system) {
        File file = getFile("reviews.txt");
        if (!file.exists()) return;
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {

                String[] p = line.split(",");
                if (p.length != 5) continue;

                String reviewerName = p[0];
                String targetName = p[1];
                int rating = Integer.parseInt(p[2]);
                String comment = p[3];
                String type = p[4];

                User reviewer = system.searchUser(reviewerName);

                if (type.equalsIgnoreCase("driver")) {
                    DeliveryPerson driver = system.searchDriver(targetName);
                    if (reviewer != null && driver != null) {
                        Review r = new Review(reviewer, driver, rating, comment);
                        system.addReview(r);
                        driver.addReview(r);
                    }
                } else {
                    Restaurant rest = system.searchRestaurant(targetName);
                    if (reviewer != null && rest != null) {
                        Review r = new Review(reviewer, rest, rating, comment);
                        system.addReview(r);
                        rest.addReview(r);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading reviews.txt: " + e.getMessage());
        }
    }
}

