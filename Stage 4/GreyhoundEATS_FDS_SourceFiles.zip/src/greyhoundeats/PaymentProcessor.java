package greyhoundeats;
import java.util.List;
import java.util.Scanner;

/**
 * PaymentProcessor
 *
 * Handles checkout and payment choices then creates an Order and attempts to assign a driver.
 */
public class PaymentProcessor {
    private Scanner in;
    private FoodDeliverySystem system;

    public PaymentProcessor(FoodDeliverySystem system) {
        this.system = system;
        this.in = new Scanner(System.in);
    }

    /**
     * Processes payment for the cart and places the order.
     *
     * @param customer customer object
     * @param restaurant restaurant
     * @param cart cart
     * @return true if placed
     */
    public boolean processPayment(User customer, Restaurant restaurant, Cart cart) {
        if (cart.getItems().isEmpty()) {
            System.out.println("Cart is empty. Cannot place order.");
            return false;
        }

        double amount = cart.getTotalPrice();
        System.out.printf("Cart total: $%.2f%n", amount);
        System.out.print("Enter payment method (Cash/Card): ");
        String method = in.nextLine().trim();

        Payment payment;
        boolean success = false;

        if (method.equalsIgnoreCase("Card")) {
            System.out.print("Enter card number: ");
            String number = in.nextLine().trim();
            System.out.print("Enter card holder name: ");
            String holder = in.nextLine().trim();
            System.out.print("Enter expiry (MM/YY): ");
            String expiry = in.nextLine().trim();
            payment = new CreditCardPayment(amount, number, holder, expiry);
            success = CreditCardPayment.processPayment();
        } else if (method.equalsIgnoreCase("Cash")) {
            payment = new CashPayment(amount);
            success = CashPayment.processPayment();
        } else {
            System.out.println("Unknown payment method. Order cancelled.");
            return false;
        }

        if (!success) {
            System.out.println("Payment failed. Order cancelled.");
            return false;
        }

        // Create order using items
        //List<MenuItem> items = cart.getItems();
        Order order = new Order(customer, restaurant, cart);

        system.addOrder(order);
        system.assignDeliveryPerson(order);

        if (order.getDeliveryPerson() != null) {
            order.setStatus("On Delivery");
            System.out.println("Order placed successfully! Driver assigned: " + order.getDeliveryPerson().getName());
        } else {
            System.out.println("Order placed successfully! No driver available right now; order queued.");
        }

        cart.deleteCart();
        return true;
    }
}
