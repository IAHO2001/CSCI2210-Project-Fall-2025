public interface MenuInterface {
    void showMenu();
}
