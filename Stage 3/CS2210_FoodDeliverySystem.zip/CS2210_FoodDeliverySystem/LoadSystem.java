public class LoadSystem{
    public static void loadSystem(FoodDeliverySystem system) {
        // Admins
        Admin jacob = new Admin("Jacob", "jacob@gmail.com", "Jacob123", "505-123-4567", "Super Admin");
        Admin miranda = new Admin("Miranda", "miranda@gmail.com", "Miranda123" ,"575-123-4567", "Restaurant Admin");
        Admin iris = new Admin("Iris", "iris@gmail.com", "Iris123", "575-321-7654", "Operations Admin");

        system.addAdmin(jacob);
        system.addAdmin(miranda);
        system.addAdmin(iris);

        // Aj's Wings
        Restaurant rest1 = new Restaurant("Aj's Wings", "456 Main Ave", "575-2468");
        system.addRestaurant(rest1);

        // Aj's Wings menu
        Menu menu1 = new Menu(rest1);
        MenuItem wings = new MenuItem("Wings", 9.99);
        MenuItem burger = new MenuItem("Burger", 11.49);
        MenuItem fries = new MenuItem("Fries", 4.00);

        menu1.addMenuItem(wings);
        menu1.addMenuItem(burger);
        menu1.addMenuItem(fries);
        rest1.setMenu(menu1);

        // Tacob Bell
        Restaurant rest2 = new Restaurant("Taco Bell", "123 Main Ave", "575-123-456");
        system.addRestaurant(rest2);

        //Taco Bell menu
        Menu menu2 = new Menu(rest2);
        MenuItem Taco = new MenuItem("Taco", 2.50);
        MenuItem burrito = new MenuItem("Burrito", 4.25);
        MenuItem combo = new MenuItem("Combo(Taco, Burrito, Drink)", 9.50);

        menu2.addMenuItem(Taco);
        menu2.addMenuItem(burrito);
        menu2.addMenuItem(combo);
        rest2.setMenu(menu2);

        //Deliver Drivers
        DeliveryPerson driver1 = new DeliveryPerson("Greyhound", "greyhound@gmail.com", "555-0000", "Greyhounds123","Scooter", "Available", system);
        DeliveryPerson driver2 = new DeliveryPerson("Eduardo", "Eduardo@gmail.com", "555-2222", "Eduardo123", "Car", "Available", system);

        system.addDeliveryPerson(driver1);
        system.addDeliveryPerson(driver2);

        //Customers
        User customer1 = new User("Bob", "Bob@gmail.com", "575-123-4321", "Bob123", "567 Bob Ave");
        User customer2 = new User("Sally", "Sally@gmail.com", "575-456-6543", "Sally123", "789 Sally Ave");

        system.addUser(customer1);
        system.addUser(customer2);

        //Bob cart and order
        Cart bobCart = new Cart(customer1);
        bobCart.addItem(Taco);
        bobCart.addItem(combo);

        Order bobOrder = new Order(customer1, rest2, bobCart);
        system.assignDeliveryPerson(bobOrder);
        system.addOrder(bobOrder);

        //Sally car and order
        Cart sallyCart = new Cart(customer2);
        sallyCart.addItem(wings);
        sallyCart.addItem(fries);

        Order sallyOrder = new Order(customer2, rest1, sallyCart);
        system.assignDeliveryPerson(sallyOrder);
        system.addOrder(sallyOrder);

        //Greyhound completes Bob's order
        bobOrder.setStatus("Completed");
        driver1.getAssignedOrders().remove(bobOrder);
        driver1.setAvailability("Available");

        //Bob leaves a review
        Review bobDriverReview = new Review(customer1, driver1, 5, "Very fast delivery!");
        Review bobRestaurantReview = new Review(customer1, rest2, 5, "Tacos were very good!");

        system.addReview(bobDriverReview);
        system.addReview(bobRestaurantReview);
        rest2.addReview(bobRestaurantReview);
        driver1.addReview(bobDriverReview);
    }
}
