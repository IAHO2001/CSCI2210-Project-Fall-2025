
import java.util.List;
import java.util.Scanner;

public class DriverMenu implements MenuInterface {
    //Instance variables
    private DriverMenuManager manager;

    /**
     * 
     */
    public DriverMenu() {
        this.manager = new DriverMenuManager();
    }

    /**
     * 
     * @param driver
     */
    public void showMenu(DeliveryPerson driver) {
        Scanner in = new Scanner(System.in);
        int option;

        do {
            System.out.println("\n--- Delivery Driver Menu ---");
            System.out.println("1. View Assigned Orders");
            System.out.println("2. Mark Order as Completed");
            System.out.println("3. View My Reviews");
            System.out.println("4. Logout");
            System.out.print("Choose an option: ");
            option = in.nextInt();
            in.nextLine(); // consume newline

            switch (option) {
                case 1:
                    manager.viewAssignedOrders(driver);
                    break;
                case 2:
                    manager.completeOrder(driver);
                    break;
                case 3:
                    manager.viewDriverReviews(driver);
                    break;
                case 4: 
                    System.out.println("Logging out...");
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }

        } while (option != 4);
    }

    /**
     * 
     */
    @Override
    public void showMenu() {
        System.out.println("No driver logged in.");
    }
}