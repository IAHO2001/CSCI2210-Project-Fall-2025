import java.util.Scanner;

public class PaymentProcessor {
    //Instance Variables
    private Scanner in;
    private FoodDeliverySystem system;

    /**
     * Constructor
     * @param system
     */
    public PaymentProcessor(FoodDeliverySystem system){
        this.system = system;
        this.in = new Scanner(System.in);
    }

    /**
     * 
     * @param customer
     * @param restaurant
     * @param cart
     */
    public void processPayment(User customer, Restaurant restaurant, Cart cart){
        if (cart.getItems().isEmpty()) {
            System.out.println("Cart is empty. Cannot place order.");
            return;
        }

        System.out.print("Enter payment method (Cash/Card): ");
        String method = in.nextLine();

        Payment payment = new Payment(new Order(customer, restaurant, cart), method);

        boolean paid = false;
        while (!paid) {
            double remaining = payment.getRemainingAmount();
            System.out.println("Cart total: $" + String.format("%.2f", remaining));
            System.out.print("Enter amount to pay: ");
            double amount = in.nextDouble();
            in.nextLine(); // consume newline

            paid = payment.processPayment(amount);

            if (!paid) {
                System.out.print("Do you want to pay the remaining amount? (yes/no): ");
                String choice = in.nextLine().trim();

                if (!choice.equalsIgnoreCase("yes")) {
                    System.out.println("Order cancelled.");
                    cart.deleteCart();
                    return;
                }
            }
        }

        
        Order order = payment.getOrder();
        system.addOrder(order);
        DeliveryPerson driver = system.assignDeliveryPerson(order);
        System.out.println("Order placed successfully!");
        System.out.println("Assigned driver: " + (driver != null ? driver.getName() : "None available"));
        System.out.println("Total paid: $" + String.format("%.2f", payment.getAmount()));

        // Clear the cart
        cart.deleteCart();
    }


}
