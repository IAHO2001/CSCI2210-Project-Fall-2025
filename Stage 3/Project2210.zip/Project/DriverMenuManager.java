import java.util.List;
import java.util.Scanner;

public class DriverMenuManager {
    //Initate Scanner
    private Scanner in = new Scanner(System.in);

    /**
     * 
     * @param driver
     */
    public void viewAssignedOrders(DeliveryPerson driver) {
        List<Order> orders = driver.getAssignedOrders();

        System.out.println("\n--- Assigned Orders ---");
        if (orders == null || orders.isEmpty()) {
            System.out.println("You have no assigned orders.");
            return;
        }

        for (Order order : orders) {
            System.out.printf("Order ID: %d | Restaurant: %s | Total: $%.2f | Status: %s%n",
                    order.getOrderID(),
                    order.getRestaurant().getName(),
                    order.getTotalPrice(),
                    order.getStatus());
        }
    }

    /**
     * 
     * @param driver
     */
    public void completeOrder(DeliveryPerson driver) {
        List<Order> orders = driver.getAssignedOrders();

        if (orders == null || orders.isEmpty()) {
            System.out.println("No active orders to complete.");
            return;
        }

        System.out.println("\n--- Complete Order ---");
        for (int i = 0; i < orders.size(); i++) {
            Order order = orders.get(i);
            System.out.printf("%d. Order ID: %d | Restaurant: %s | Status: %s%n",
                    i + 1,
                    order.getOrderID(),
                    order.getRestaurant().getName(),
                    order.getStatus());
        }

        System.out.print("Select an order to mark as completed: ");
        int choice = in.nextInt();
        in.nextLine();

        if (choice >= 1 && choice <= orders.size()) {
            Order selectedOrder = orders.get(choice - 1);
            selectedOrder.setStatus("Completed");
            System.out.println("Order ID " + selectedOrder.getOrderID() + " has been marked as completed.");
            driver.setAvailability("Available");
            driver.getAssignedOrders().remove(selectedOrder);
        } else {
            System.out.println("Invalid choice.");
        }
    }

    /**
     * 
     * @param driver
     */
    public void viewDriverReviews(DeliveryPerson driver) {
        List<Review> reviews = driver.getReviews();

        System.out.println("\n--- My Reviews ---");
        if (reviews == null || reviews.isEmpty()) {
            System.out.println("You have no reviews yet.");
            return;
        }

        System.out.println("Average Rating: " + driver.getAverageRating());

        for (Review review : reviews) {
            System.out.printf("Review ID: %d | Rating: %d | Comment: %s | Reviewer: %s%n",
                    review.getReviewid(),
                    review.getRating(),
                    review.getComment(),
                    review.getReviewer().getName());
        }
    }
}

