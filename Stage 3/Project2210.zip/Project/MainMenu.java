import java.util.Scanner;

public class MainMenu implements MenuInterface {
    //Instance Variables
    private FoodDeliverySystem system;
    private AdminMenu adminMenu;
    private CustomerMenu customerMenu;
    private DriverMenu driverMenu;

    /**
     * Constructor Initializes Menus
     * @param system
     */
    public MainMenu(FoodDeliverySystem system) {
        this.system = system;
        this.adminMenu = new AdminMenu(system);
        this.customerMenu = new CustomerMenu(system, null);
        this.driverMenu = new DriverMenu();
    }

    /**
     * 
     */
    @Override
    public void showMenu() {
        Scanner in = new Scanner(System.in);
        int option = 0;

        do {
            System.out.println("\n=== Food Delivery System ===");
            System.out.println("1. Login as Admin");
            System.out.println("2. Login as Customer");
            System.out.println("3. Login as Delivery Driver");
            System.out.println("4. Create a New Customer");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            option = in.nextInt();
            in.nextLine(); // consume newline

            switch (option) {
                case 1:
                    loginAdmin();
                    break;
                case 2:
                    loginCustomer();
                    break;
                case 3:
                    loginDriver();
                    break;
                case 4:
                    createNewCustomer();
                    break;
                case 5:
                    System.out.println("Exiting. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        } while (option != 5);
    }

    /**
     * 
     */
    private void loginAdmin() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter admin email: ");
        String email = in.nextLine();

        Admin admin = system.getLoginManager().loginAdmin(email, system.getAdmins());
        if (admin != null) {
            adminMenu.showMenu(admin);
        } else {
            System.out.println("Admin not found.");
        }
    }

    /**
     * 
     */
    private void loginCustomer() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter email: ");
        String email = in.nextLine();
        System.out.print("Enter password: ");
        String password = in.nextLine();

        User customer = system.getLoginManager().loginUser(email, password, system.getUsers());
        if (customer != null) {
            CustomerMenu customerMenu = new CustomerMenu(system, customer);
            customerMenu.showMenu(customer);
        } else {
            System.out.println("Invalid email/password.");
        }
    }

    /**
     * 
     */
    private void createNewCustomer(){
        Scanner in = new Scanner(System.in);
        System.out.print("Enter customer name: ");
        String name = in.nextLine();
        System.out.print("Enter email: ");
        String email = in.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = in.nextLine();
        System.out.print("Enter password: ");
        String password = in.nextLine();
        System.out.print("Enter address: ");
        String address = in.nextLine();

        User newUser = new User(name, email, phoneNumber, password, address);
        system.addUser(newUser);
        System.out.println("Customer accound created.");
    }

    /**
     * 
     */
    private void loginDriver() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter driver email: ");
        String email = in.nextLine();

        DeliveryPerson driver = system.getLoginManager().loginDriver(email, system.getDeliveryPersonnel());
        if (driver != null) {
            driverMenu.showMenu(driver);
        } else {
            System.out.println("Delivery driver not found.");
        }
    }
}
