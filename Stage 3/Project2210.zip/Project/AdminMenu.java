import java.util.Scanner;

public class AdminMenu implements MenuInterface{
    //Instance Variable
    private AdminMenuManager manager ;

    /**
     * Constructor
     * @param system
     */
    public AdminMenu(FoodDeliverySystem system) {
        this.manager = new AdminMenuManager(system);
    }

    /**
     * 
     */
    @Override
    public void showMenu(){
        System.out.println("No admin logged in.");
    }

    /**
     * 
     * @param admin
     */
    public void showMenu(Admin admin) {
        Scanner in = new Scanner(System.in);
        int option = 0;

        do {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add Delivery Driver");
            System.out.println("2. Edit Delivery Driver");
            System.out.println("3. View All Drivers");
            System.out.println("4. View All Users");
            System.out.println("5. View All Orders");
            System.out.println("6. Logout");
            System.out.print("Choose an option: ");
            option = in.nextInt();
            in.nextLine(); // consume newline

            switch (option) {
                case 1:
                    manager.addDeliveryDriver();
                    break;
                case 2:
                    manager.editDeliveryDriver();
                    break;
                case 3:
                    manager.viewDeliveryDrivers();
                    return;
                case 4:
                    manager.viewAllUsers();
                    break;
                case 5:
                    manager.viewAllOrders();
                    break;
                case 6:
                    System.out.println("Logging out...");
                    break;
                default:
                    System.out.println("Invalid option.");
            }

        } while (option != 6);
    }
}