import java.util.List;
import java.util.Scanner;

public class AdminMenuManager {
    //Instance Variables
    private FoodDeliverySystem system;
    private Scanner in;

    /**
     * 
     * @param system
     */
    public AdminMenuManager(FoodDeliverySystem system) {
        this.system = system;
        this.in = new Scanner(System.in);
    }

    /**
     * 
     */
    public void addDeliveryDriver() {
        Scanner in = new Scanner(System.in);

        System.out.print("Enter driver name: ");
        String name = in.nextLine();

        System.out.print("Enter driver email: ");
        String email = in.nextLine();

        System.out.print("Enter phone number: ");
        String phoneNumber = in.nextLine();

        System.out.print("Enter vehicle type: ");
        String vehicleType = in.nextLine();

        System.out.print("Enter availability: ");
        String availability = in.nextLine();

        DeliveryPerson d = new DeliveryPerson(name, email, phoneNumber, vehicleType, availability);
        system.addDeliveryPerson(d);
        System.out.println("Driver added.");
    }

    /**
     * 
     */
    public void viewDeliveryDrivers() {
        if(system.getDeliveryPersonnel().isEmpty()) {
            System.out.println("No registered drivers.");
            return;
        }

        for(DeliveryPerson d : system.getDeliveryPersonnel()) {
            System.out.println(d.getName() + " | " + d.getPhoneNumber() + " | " + d.getAvailability() + " | " + d.getAverageRating());
        }
    }

    /**
     * 
     */
    public void editDeliveryDriver() {
        Scanner in = new Scanner(System.in);
        List<DeliveryPerson> drivers = system.getDeliveryPersonnel();

        if (drivers.isEmpty()) {
            System.out.println("No drivers available.");
            return;
        }

        System.out.println("--- Delivery Drivers ---");
        for (int i = 0; i < drivers.size(); i++) {
            DeliveryPerson d = drivers.get(i);
            System.out.printf("%d. %s | Email: %s | Vehicle: %s | Availability: %s%n",
                    i + 1, d.getName(), d.getEmail(), d.getVehicleType(), d.getAvailability());
        }

        System.out.print("Select driver to edit by number: ");
        int choice = in.nextInt();
        in.nextLine();

        if (choice < 1 || choice > drivers.size()) {
            System.out.println("Invalid selection.");
            return;
        }

        DeliveryPerson driver = drivers.get(choice - 1);

        System.out.print("Enter new name (leave blank to keep current): ");
        String name = in.nextLine();
        if (!name.isBlank()) driver.setName(name);

        System.out.print("Enter new vehicle type (leave blank to keep current): ");
        String vehicle = in.nextLine();
        if (!vehicle.isBlank()) driver.setVehicleType(vehicle);

        System.out.print("Enter new availability (leave blank to keep current): ");
        String availability = in.nextLine();
        if (!availability.isBlank()) driver.setAvailability(availability);

        System.out.println("Driver updated successfully!");
    }

    /**
     * 
     */
    public void viewAllUsers() {
        if(system == null){
            System.out.println("System not initialized");
            return;
        }

        if(system.getUsers().isEmpty()){
            System.out.println("There are no users in this system.");
            return;
        }

        System.out.println("--- All Users ---");
        for (User u : system.getUsers()) {
            System.out.printf("Name: %s | Email: %s%n", u.getName(), u.getEmail());
        }
    }

    /**
     * 
     */
    public void viewAllOrders() {
        List<Order> orders = system.getOrders();

        System.out.println("--- All Orders ---");
        if(orders.isEmpty()){
            System.out.println("No orders found.");
            return;
        }
        for (Order order : orders) {
            String customerName = (order.getCustomer() != null) ? order.getCustomer().getName() : "Unknown Customer";
            System.out.printf("Order ID: %d | Customer: %s | Total: $%.2f | Status: %s%n",
                    order.getOrderID(), customerName, order.getTotalPrice(), order.getStatus());
        }
    }
}
